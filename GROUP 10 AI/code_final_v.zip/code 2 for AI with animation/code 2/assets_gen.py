"""assets_gen.py
Helper to generate small placeholder PNG sprites for the Prisoners Dilemma app.
If Pillow is available it will be used to create PNGs. Otherwise it will fall back
to using Tkinter PhotoImage (and attempt to write PNG, or PPM as a fallback).
"""
import os

SPRITES = {
    'prisoner1.png': {'color': '#5fb3ff', 'label': 'P1'},
    'prisoner2.png': {'color': '#ffb86b', 'label': 'P2'},
    'officer.png': {'color': '#99d1ff', 'label': 'O'}
}

# Larger placeholder size for better legibility
SIZE = (64, 64)


def ensure_assets(folder='assets', overwrite=False):
    os.makedirs(folder, exist_ok=True)

    # Try Pillow first for best PNG output
    try:
        from PIL import Image, ImageDraw, ImageFont
        pil_ok = True
    except Exception:
        pil_ok = False

    for name, meta in SPRITES.items():
        path = os.path.join(folder, name)
        if os.path.exists(path) and not overwrite:
            continue

        print(f"Generating sprite: {path}")

        if pil_ok:
            img = Image.new('RGBA', SIZE, (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)
            cx, cy = SIZE[0] // 2, SIZE[1] // 2
            # slightly larger head radius for 64x64
            r = 22
            # circle body
            draw.ellipse((cx - r, cy - r - 4, cx + r, cy + r - 4), fill=meta['color'])
            # small cap for officer
            if name == 'officer.png':
                draw.rectangle((cx - 18, cy - 26, cx + 18, cy - 12), fill="#143b6b")
            # label
            try:
                f = ImageFont.load_default()
                draw.text((6, SIZE[1] - 14), meta['label'], font=f, fill='white')
            except Exception:
                pass
            img.save(path, format='PNG')
            continue

        # Fallback: use Tk PhotoImage to produce a simple square/circle, and try to write PNG
        try:
            import tkinter as tk
            root = tk.Tk()
            root.withdraw()
            img = tk.PhotoImage(width=SIZE[0], height=SIZE[1])
            # Fill transparent background
            for y in range(SIZE[1]):
                for x in range(SIZE[0]):
                    img.put("#00000000", (x, y))
            # draw a circle approximated by filling pixels within radius
            cx, cy = SIZE[0] // 2, SIZE[1] // 2 - 2
            r = 22
            col = meta['color']
            for y in range(SIZE[1]):
                for x in range(SIZE[0]):
                    if (x - cx) ** 2 + (y - cy) ** 2 <= r * r:
                        img.put(col, (x, y))
            # try writing PNG (not guaranteed available)
            try:
                img.write(path, format='png')
                root.destroy()
                continue
            except Exception:
                # write PPM as fallback and rename to .ppm if necessary
                ppm_path = os.path.splitext(path)[0] + '.ppm'
                img.write(ppm_path, format='ppm')
                root.destroy()
                continue
        except Exception:
            # Give up; skip file creation and rely on drawn fallback in main app
            print(f"Unable to create sprite {name} (Pillow/Tk write unavailable). Using drawn fallback.")
            continue

    print("Asset generation complete.")
