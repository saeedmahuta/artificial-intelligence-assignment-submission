"""
Prisoner's Dilemma Problem code 2
"""

import customtkinter as ctk
import random
import tkinter as tk
import os
from assets_gen import ensure_assets

# Constants
BUTTON_WIDTH = 120
BUTTON_HEIGHT = 50
FONT_SIZE = 14
HEADER_FONT_SIZE = 16
LABEL_FONT_SIZE = 12
BUTTON_FONT = ('Segoe UI', FONT_SIZE)
HEADER_FONT = ('Segoe UI', HEADER_FONT_SIZE, 'bold')
LABEL_FONT = ('Segoe UI', LABEL_FONT_SIZE, 'bold')

# Colors
PENALTY_GREEN = "green"
PENALTY_RED = "red"
PENALTY_GRAY = "gray"

# Animation / Canvas settings
CANVAS_WIDTH = 600
CANVAS_HEIGHT = 240
P1_COLOR = "skyblue"
P2_COLOR = "orange"
OFFICER_COLOR = "#99ccff"
BAR_COLOR = "#b8b8b8"
ANIM_BG = "#2b2b2b"
ANIM_FRAMES = 26
ANIM_DELAY = 18  # ms between frames
JAIL_BAR_COUNT = 7


class GameEngine:
    """Core game logic separated from UI"""

    REWARDS = {
        ('C', 'C'): (1, 1),
        ('C', 'D'): (5, 0),
        ('D', 'C'): (0, 5),
        ('D', 'D'): (3, 3)
    }

    def __init__(self):
        self.p1_moves = []
        self.p2_moves = []
        self.p1_penalties = []
        self.p2_penalties = []
        self.total_p1 = 0
        self.total_p2 = 0
        self.rounds_played = 0

    def play_round(self, p1_choice, p2_choice):
        """Process a single round"""
        penalty1, penalty2 = self.REWARDS[(p1_choice, p2_choice)]

        self.p1_moves.append(p1_choice)
        self.p2_moves.append(p2_choice)
        self.p1_penalties.append(penalty1)
        self.p2_penalties.append(penalty2)

        self.total_p1 += penalty1
        self.total_p2 += penalty2
        self.rounds_played += 1

        return penalty1, penalty2

    def clear(self):
        """Reset all game state"""
        self.p1_moves.clear()
        self.p2_moves.clear()
        self.p1_penalties.clear()
        self.p2_penalties.clear()
        self.total_p1 = 0
        self.total_p2 = 0
        self.rounds_played = 0


class AIPlayer:
    """AI strategies"""

    @staticmethod
    def pure_random(opp_moves, my_moves):
        """Random choice"""
        return random.choice(['C', 'D'])


class PrisonersDilemmaGUI:
    """GUI Controller"""

    def __init__(self, root):
        self.root = root
        self.root.title("Prisoner's Dilemma Simulator")
        self.root.geometry("1000x700")

        # Set customtkinter appearance
        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("green")

        self.engine = GameEngine()
        self.ai_opponent = None
        self.waiting_for = set()
        self.pending_p1 = None
        self.pending_p2 = None

        # Ensure sprite assets exist (creates PNG placeholders if Pillow/Tk available)
        try:
            assets_dir = os.path.join(os.path.dirname(__file__), 'assets')
            # overwrite to refresh with larger sprites
            ensure_assets(assets_dir, overwrite=True)
        except Exception:
            # silently continue; drawn fallback will be used
            pass

        self.ai_strategies = {
            'Human Player': None,
            'Random Bot': AIPlayer.pure_random
        }

        self.build_interface()
        self.new_game()
    
    def build_interface(self):
        """UI elements"""

        # Control Panel
        ctrl_frame = ctk.CTkFrame(self.root, corner_radius=4)
        ctrl_frame.pack(pady=10, padx=20, anchor='center')

        ctk.CTkLabel(ctrl_frame, text="Player 2:").grid(row=0, column=0, padx=(10,0), pady=5)
        self.ai_var = ctk.StringVar(value='Random Bot')
        ai_menu = ctk.CTkComboBox(ctrl_frame, variable=self.ai_var,
                                  values=list(self.ai_strategies.keys()), width=200)
        ai_menu.grid(row=0, column=1, padx=(0,10), pady=5)

        ctk.CTkButton(ctrl_frame, text="New Game", command=self.new_game).grid(row=0, column=2, padx=10, pady=5)

        # Game instructions
        info_text = "Instructions: Each round, choose 'Cooperate' or 'Defect'. Lower prison years is better. Payoffs: (C,C)=1yr each, (D,D)=3yr each, (C,D)=5yr/0yr, (D,C)=0yr/5yr"
        ctk.CTkLabel(ctrl_frame, text=info_text, justify='left').grid(row=1, column=0, columnspan=3, padx=10, pady=5)

        # Game Display
        game_frame = ctk.CTkFrame(self.root, corner_radius=4)
        game_frame.pack(fill='both', expand=True, padx=20, pady=10)

        # Player sections side by side, centered
        players_frame = ctk.CTkFrame(game_frame, corner_radius=4)
        players_frame.pack(pady=10, anchor='center')

        # Animation area (jail cell scene)
        anim_frame = ctk.CTkFrame(game_frame, corner_radius=4)
        anim_frame.pack(pady=10)
        self.canvas = tk.Canvas(anim_frame, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg=ANIM_BG, highlightthickness=0)
        self.canvas.pack()

        # Cell bounds
        cell_top = 20
        cell_bottom = CANVAS_HEIGHT - 20
        cell_left = 80
        cell_right = CANVAS_WIDTH - 80
        self.canvas.create_rectangle(cell_left, cell_top, cell_right, cell_bottom, outline=BAR_COLOR, width=2)

        # Jail bars
        self.jail_bars = []
        spacing = (cell_right - cell_left) / (JAIL_BAR_COUNT - 1)
        for i in range(JAIL_BAR_COUNT):
            x = cell_left + i * spacing
            bar = self.canvas.create_line(x, cell_top, x, cell_bottom, fill=BAR_COLOR, width=4)
            self.jail_bars.append(bar)

        # Initial positions for prisoners and officer (adjusted for larger sprites)
        left_x = cell_left + 80
        right_x = cell_right - 80
        center_x = (cell_left + cell_right) / 2
        head_r = 24

        # Try loading sprite PNGs (fallback to drawn figures if not available)
        self.p1_img = None
        try:
            p1_path = os.path.join(os.path.dirname(__file__), 'assets', 'prisoner1.png')
            p2_path = os.path.join(os.path.dirname(__file__), 'assets', 'prisoner2.png')
            off_path = os.path.join(os.path.dirname(__file__), 'assets', 'officer.png')
            if os.path.exists(p1_path):
                self.p1_img = tk.PhotoImage(file=p1_path)
            if os.path.exists(p2_path):
                self.p2_img = tk.PhotoImage(file=p2_path)
            else:
                self.p2_img = None
            if os.path.exists(off_path):
                self.officer_img = tk.PhotoImage(file=off_path)
            else:
                self.officer_img = None
        except Exception:
            self.p1_img = self.p2_img = self.officer_img = None

        # Player 1 figure (left)
        self.p1_x = float(left_x)
        if self.p1_img:
            # place image centered a bit lower for visual balance
            p1_img_id = self.canvas.create_image(self.p1_x, cell_top + 48, image=self.p1_img)
            self.p1_parts = {'image': p1_img_id}
        else:
            p1_head = self.canvas.create_oval(self.p1_x - head_r, cell_top + 48 - head_r, self.p1_x + head_r, cell_top + 48 + head_r, fill=P1_COLOR, outline="")
            p1_body = self.canvas.create_rectangle(self.p1_x - 16, cell_top + 48 + head_r, self.p1_x + 16, cell_bottom - 12, fill="#3b82c4", outline="")
            p1_eye_l = self.canvas.create_oval(self.p1_x - 8, cell_top + 48 - 6, self.p1_x - 2, cell_top + 48 - 2, fill="white", outline="")
            p1_eye_r = self.canvas.create_oval(self.p1_x + 2, cell_top + 48 - 6, self.p1_x + 8, cell_top + 48 - 2, fill="white", outline="")
            p1_mouth = self.canvas.create_line(self.p1_x - 8, cell_top + 48 + 10, self.p1_x + 8, cell_top + 48 + 10, fill="black", width=2)
            self.p1_parts = {'head': p1_head, 'body': p1_body, 'eyes': [p1_eye_l, p1_eye_r], 'mouth': p1_mouth}

        # Player 2 figure (right)
        self.p2_x = float(right_x)
        if self.p2_img:
            p2_img_id = self.canvas.create_image(self.p2_x, cell_top + 48, image=self.p2_img)
            self.p2_parts = {'image': p2_img_id}
        else:
            p2_head = self.canvas.create_oval(self.p2_x - head_r, cell_top + 48 - head_r, self.p2_x + head_r, cell_top + 48 + head_r, fill=P2_COLOR, outline="")
            p2_body = self.canvas.create_rectangle(self.p2_x - 16, cell_top + 48 + head_r, self.p2_x + 16, cell_bottom - 12, fill="#ff8a00", outline="")
            p2_eye_l = self.canvas.create_oval(self.p2_x - 8, cell_top + 48 - 6, self.p2_x - 2, cell_top + 48 - 2, fill="white", outline="")
            p2_eye_r = self.canvas.create_oval(self.p2_x + 2, cell_top + 48 - 6, self.p2_x + 8, cell_top + 48 - 2, fill="white", outline="")
            p2_mouth = self.canvas.create_line(self.p2_x - 8, cell_top + 48 + 10, self.p2_x + 8, cell_top + 48 + 10, fill="black", width=2)
            self.p2_parts = {'head': p2_head, 'body': p2_body, 'eyes': [p2_eye_l, p2_eye_r], 'mouth': p2_mouth}

        # Officer figure (center, outside cell, above)
        self.officer_x = float(center_x)
        if self.officer_img:
            off_img_id = self.canvas.create_image(self.officer_x, cell_top + 10, image=self.officer_img)
            self.officer_parts = {'image': off_img_id}
        else:
            off_head = self.canvas.create_oval(self.officer_x - 16, cell_top - 6, self.officer_x + 16, cell_top + 26, fill=OFFICER_COLOR, outline="")
            off_body = self.canvas.create_rectangle(self.officer_x - 18, cell_top + 26, self.officer_x + 18, cell_top + 66, fill="#1f77b4", outline="")
            off_cap = self.canvas.create_rectangle(self.officer_x - 18, cell_top - 18, self.officer_x + 18, cell_top - 6, fill="#143b6b", outline="")
            self.officer_parts = {'head': off_head, 'body': off_body, 'cap': off_cap}

        # Labels
        self.canvas.create_text(left_x, cell_bottom - 8, text="Prisoner 1", fill="white", font=("Segoe UI", 10))
        self.canvas.create_text(right_x, cell_bottom - 8, text="Prisoner 2", fill="white", font=("Segoe UI", 10))
        self.canvas.create_text(center_x, 12, text="Officer", fill="white", font=("Segoe UI", 10))

        self.animating = False

        # Player 1
        p1_frame = ctk.CTkFrame(players_frame, corner_radius=4)
        p1_frame.pack(side='left', padx=(0, 40))
        ctk.CTkLabel(p1_frame, text="Player 1 (You)", font=HEADER_FONT).pack(pady=10)

        # Buttons side by side
        buttons_frame1 = ctk.CTkFrame(p1_frame, corner_radius=4)
        buttons_frame1.pack(pady=10)
        self.p1_coop = ctk.CTkButton(buttons_frame1, text="Cooperate",
                                     command=lambda: self.make_move(1, 'C'), width=BUTTON_WIDTH, height=BUTTON_HEIGHT, font=BUTTON_FONT, corner_radius=4)
        self.p1_coop.pack(side='left', padx=5)

        self.p1_def = ctk.CTkButton(buttons_frame1, text="Defect",
                                    command=lambda: self.make_move(1, 'D'), width=BUTTON_WIDTH, height=BUTTON_HEIGHT, font=BUTTON_FONT, corner_radius=4)
        self.p1_def.pack(side='left', padx=5)

        # Player 2
        p2_frame = ctk.CTkFrame(players_frame, corner_radius=4)
        p2_frame.pack(side='left', padx=(40, 0))
        ctk.CTkLabel(p2_frame, text="Player 2", font=HEADER_FONT).pack(pady=10)

        # Buttons side by side
        buttons_frame2 = ctk.CTkFrame(p2_frame, corner_radius=4)
        buttons_frame2.pack(pady=10)
        self.p2_coop = ctk.CTkButton(buttons_frame2, text="Cooperate",
                                     command=lambda: self.make_move(2, 'C'), width=BUTTON_WIDTH, height=BUTTON_HEIGHT, font=BUTTON_FONT, corner_radius=4)
        self.p2_coop.pack(side='left', padx=5)

        self.p2_def = ctk.CTkButton(buttons_frame2, text="Defect",
                                    command=lambda: self.make_move(2, 'D'), width=BUTTON_WIDTH, height=BUTTON_HEIGHT, font=BUTTON_FONT, corner_radius=4)
        self.p2_def.pack(side='left', padx=5)

        # History table under players
        history_frame = ctk.CTkFrame(game_frame, corner_radius=4)
        history_frame.pack(fill='both', expand=True, pady=5)
        ctk.CTkLabel(history_frame, text="Match History", font=HEADER_FONT).pack(pady=5)

        self.history_scrollable = ctk.CTkScrollableFrame(history_frame)
        self.history_scrollable.pack(fill='both', expand=True, padx=10, pady=5)

        # Header
        header_frame = ctk.CTkFrame(self.history_scrollable)
        header_frame.pack(fill='x', pady=2)
        ctk.CTkLabel(header_frame, text="Round", font=LABEL_FONT, width=60).pack(side='left', padx=5)
        ctk.CTkLabel(header_frame, text="P1 Choice", font=LABEL_FONT, width=80).pack(side='left', padx=5)
        ctk.CTkLabel(header_frame, text="P1 Penalty", font=LABEL_FONT, width=80).pack(side='left', padx=5)
        ctk.CTkLabel(header_frame, text="P2 Choice", font=LABEL_FONT, width=80).pack(side='left', padx=5)
        ctk.CTkLabel(header_frame, text="P2 Penalty", font=LABEL_FONT, width=80).pack(side='left', padx=5)

        # Round and Score at bottom
        status_frame = ctk.CTkFrame(game_frame, corner_radius=4)
        status_frame.pack(fill='x', pady=10)
        self.round_label = ctk.CTkLabel(status_frame, text="Round: 0", font=HEADER_FONT)
        self.round_label.pack(side='left', padx=20)
        self.score_label = ctk.CTkLabel(status_frame, text="P1: 0 yrs | P2: 0 yrs", font=('Segoe UI', 14))
        self.score_label.pack(side='right', padx=20)

        self.toggle_buttons(False)



    def add_history_row(self, round_num, p1_choice, p2_choice, p1_pen, p2_pen):
        """Add a row to the history table"""
        row_frame = ctk.CTkFrame(self.history_scrollable)
        row_frame.pack(fill='x', pady=2)

        # Round
        ctk.CTkLabel(row_frame, text=str(round_num), width=60).pack(side='left', padx=5)

        # P1 Choice
        ctk.CTkLabel(row_frame, text=p1_choice, width=80).pack(side='left', padx=5)

        # P1 Penalty
        penalty_color = PENALTY_GREEN if p1_pen <= 1 else PENALTY_RED if p1_pen == 5 else PENALTY_GRAY
        ctk.CTkLabel(row_frame, text=f"{p1_pen} yrs", width=80, fg_color=penalty_color, corner_radius=4).pack(side='left', padx=5)

        # P2 Choice
        ctk.CTkLabel(row_frame, text=p2_choice, width=80).pack(side='left', padx=5)

        # P2 Penalty
        penalty_color = PENALTY_GREEN if p2_pen <= 1 else PENALTY_RED if p2_pen == 5 else PENALTY_GRAY
        ctk.CTkLabel(row_frame, text=f"{p2_pen} yrs", width=80, fg_color=penalty_color, corner_radius=4).pack(side='left', padx=5)
    
    def toggle_buttons(self, enabled):
        """Enable/disable player buttons"""
        state = 'normal' if enabled else 'disabled'
        self.p1_coop['state'] = state
        self.p1_def['state'] = state
        
        # P2 only if human opponent
        if self.ai_opponent is None:
            self.p2_coop['state'] = state
            self.p2_def['state'] = state
        else:
            self.p2_coop['state'] = 'disabled'
            self.p2_def['state'] = 'disabled'
    
    def new_game(self):
        """Start new game session"""
        
        self.engine.clear()
        self.waiting_for.clear()

        ai_choice = self.ai_var.get()
        self.ai_opponent = self.ai_strategies[ai_choice]
        
        self.toggle_buttons(True)
        self.update_display()
    

    def make_move(self, player, choice):
        """Handle player move"""
        self.waiting_for.add(player)

        # If AI opponent and P1 moved, get AI move immediately
        if player == 1 and self.ai_opponent is not None:
            ai_choice = self.ai_opponent(self.engine.p1_moves, self.engine.p2_moves)
            self.waiting_for.add(2)
            round_num = self.engine.rounds_played + 1
            self.add_history_row(round_num, choice, ai_choice, 0, 0)
            self.process_round(choice, ai_choice)
        # Both humans ready 
        elif len(self.waiting_for) == 2:
            p1_choice = choice if player == 1 else self.pending_p1
            p2_choice = choice if player == 2 else self.pending_p2
            round_num = self.engine.rounds_played + 1
            self.add_history_row(round_num, p1_choice, p2_choice, 0, 0)
            self.process_round(p1_choice, p2_choice)
        else:
            # Store pending move
            if player == 1:
                self.pending_p1 = choice
            else:
                self.pending_p2 = choice
    
    def process_round(self, p1_choice, p2_choice):
        """Execute round"""
        pen1, pen2 = self.engine.play_round(p1_choice, p2_choice)

        # Update the last row's penalties
        if self.history_scrollable.winfo_children():
            last_row = self.history_scrollable.winfo_children()[-1]
            row_children = last_row.winfo_children()
            if len(row_children) >= 5:
                # P1 Penalty
                penalty_color = PENALTY_GREEN if pen1 <= 1 else PENALTY_RED if pen1 == 5 else PENALTY_GRAY
                row_children[2].configure(text=f"{pen1} yrs", fg_color=penalty_color, corner_radius=4)
                # P2 Penalty
                penalty_color = PENALTY_GREEN if pen2 <= 1 else PENALTY_RED if pen2 == 5 else PENALTY_GRAY
                row_children[4].configure(text=f"{pen2} yrs", fg_color=penalty_color, corner_radius=4)

        self.waiting_for.clear()
        self.update_display()

        # Animate icons based on outcome
        self.animate_outcome(p1_choice, p2_choice)

        # Reset pending moves to prevent stale state in human-vs-human mode
        self.pending_p1 = None
        self.pending_p2 = None
        

    def update_display(self):
        """Refresh UI labels"""
        self.round_label.configure(text=f"Round: {self.engine.rounds_played}")
        self.score_label.configure(text=f"P1: {self.engine.total_p1} yrs | P2: {self.engine.total_p2} yrs")

    def animate_outcome(self, p1_choice, p2_choice):
        """Animate prisoners and officer based on choices"""
        if not hasattr(self, 'canvas'):
            return
        if self.animating:
            return
        self.animating = True

        cell_left = 80
        cell_right = CANVAS_WIDTH - 80
        center = (cell_left + cell_right) / 2

        # Targets: prisoners move relative to center; officer moves in/out
        if p1_choice == 'C' and p2_choice == 'C':
            target_p1 = center - 60
            target_p2 = center + 60
            officer_target = center - 0
            bar_shake = 0
        elif p1_choice == 'D' and p2_choice == 'D':
            target_p1 = cell_left + 40
            target_p2 = cell_right - 40
            officer_target = center
            bar_shake = 6
        elif p1_choice == 'D' and p2_choice == 'C':
            # p1 defects, moves slightly toward officer (center); p2 retreats
            target_p1 = center - 10
            target_p2 = cell_right - 40
            officer_target = center - 8
            bar_shake = 8
        else:  # p1 C, p2 D
            target_p1 = cell_left + 40
            target_p2 = center + 10
            officer_target = center + 8
            bar_shake = 8

        self._anim_step = 0
        self._anim_frames = ANIM_FRAMES
        self._anim_targets = (float(target_p1), float(target_p2), float(officer_target), float(bar_shake))
        self._anim_start = (float(self.p1_x), float(self.p2_x), float(self.officer_x))
        self._run_anim()

    def _run_anim(self):
        """Animation step runner (moves prisoner parts, officer, and shakes bars)"""
        if self._anim_step >= self._anim_frames:
            target_p1, target_p2, target_off, _ = self._anim_targets
            dx1 = target_p1 - self.p1_x
            dx2 = target_p2 - self.p2_x
            dx_off = target_off - self.officer_x
            # Move final positions
            for part in self.p1_parts.values():
                if isinstance(part, list):
                    for pid in part:
                        self.canvas.move(pid, dx1, 0)
                else:
                    self.canvas.move(part, dx1, 0)
            for part in self.p2_parts.values():
                if isinstance(part, list):
                    for pid in part:
                        self.canvas.move(pid, dx2, 0)
                else:
                    self.canvas.move(part, dx2, 0)
            for part in self.officer_parts.values():
                self.canvas.move(part, dx_off, 0)
            self.p1_x = target_p1
            self.p2_x = target_p2
            self.officer_x = target_off

            # flash colors according to last penalties
            last_p1_pen = self.engine.p1_penalties[-1] if self.engine.p1_penalties else 0
            last_p2_pen = self.engine.p2_penalties[-1] if self.engine.p2_penalties else 0
            if last_p1_pen == 5:
                self.canvas.itemconfig(self.p1_parts['head'], fill='red')
            elif last_p1_pen <= 1:
                self.canvas.itemconfig(self.p1_parts['head'], fill='green')
            else:
                self.canvas.itemconfig(self.p1_parts['head'], fill=P1_COLOR)
            if last_p2_pen == 5:
                self.canvas.itemconfig(self.p2_parts['head'], fill='red')
            elif last_p2_pen <= 1:
                self.canvas.itemconfig(self.p2_parts['head'], fill='green')
            else:
                self.canvas.itemconfig(self.p2_parts['head'], fill=P2_COLOR)

            # subtle bar settle (ensure color reset)
            for b in self.jail_bars:
                self.canvas.itemconfig(b, fill=BAR_COLOR)
                # ensure it's at base coordinates (no tracking of original coords for simplicity)
            self.root.after(550, self._reset_icon_colors)
            self.animating = False
            return

        t = (self._anim_step + 1) / self._anim_frames
        target_p1, target_p2, target_off, bar_shake = self._anim_targets
        start_p1, start_p2, start_off = self._anim_start
        new_p1 = start_p1 + (target_p1 - start_p1) * t
        new_p2 = start_p2 + (target_p2 - start_p2) * t
        new_off = start_off + (target_off - start_off) * t
        dx1 = new_p1 - self.p1_x
        dx2 = new_p2 - self.p2_x
        dx_off = new_off - self.officer_x

        # move prisoner parts
        for part in self.p1_parts.values():
            if isinstance(part, list):
                for pid in part:
                    self.canvas.move(pid, dx1, 0)
            else:
                self.canvas.move(part, dx1, 0)
        for part in self.p2_parts.values():
            if isinstance(part, list):
                for pid in part:
                    self.canvas.move(pid, dx2, 0)
            else:
                self.canvas.move(part, dx2, 0)
        # move officer
        for part in self.officer_parts.values():
            self.canvas.move(part, dx_off, 0)

        # bar shake effect (sinusoidal small offset)
        import math
        shake = math.sin((self._anim_step / max(1, self._anim_frames)) * math.pi * 2) * (bar_shake)
        for i, b in enumerate(self.jail_bars):
            # nudge each bar horizontally by small alternating amount to simulate clink
            offset = ((-1) ** i) * shake * 0.15
            self.canvas.move(b, offset, 0)

        self.p1_x = new_p1
        self.p2_x = new_p2
        self.officer_x = new_off
        self._anim_step += 1
        self.root.after(ANIM_DELAY, self._run_anim)

    def _reset_icon_colors(self):
        self.canvas.itemconfig(self.p1_parts['head'], fill=P1_COLOR)
        self.canvas.itemconfig(self.p2_parts['head'], fill=P2_COLOR)
        # reset jail bar colors
        for b in self.jail_bars:
            self.canvas.itemconfig(b, fill=BAR_COLOR)


if __name__ == '__main__':
    root = ctk.CTk()
    app = PrisonersDilemmaGUI(root)
    root.mainloop()