# Prisoner's Dilemma — CustomTkinter Demo

This is a small demo of the Prisoner's Dilemma implemented with CustomTkinter.

Features:
- Human vs Computer (Random, Tit-for-Tat, Always Cooperate, Always Defect)
- Human vs Human
- Score tracking and textual history of rounds

Requirements
- Python 3.8+
- customtkinter

Install (PowerShell):

```powershell
python -m pip install -r "requirements.txt"
```

Run the app:

```powershell
python "main.py"
```

Usage notes
- Choose an opponent type and number of rounds, then click "Start / Restart".
- If the opponent is "Human", both players can press their move buttons. If the opponent is a computer, only Player 1 selects and the computer responds.
- The years used are: (C,C)=1,1  (D,D)=3,3  (C,D)=5,0  (D,C)=0,5 (lower is better)

Next steps / enhancements
- Add automated multi-round play (auto-play with delay).
- Add plotting of cumulative scores using matplotlib.
- Add save/load of session history.

Enjoy!
