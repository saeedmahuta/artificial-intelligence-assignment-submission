import random
import os
import json
from datetime import datetime

import customtkinter as ctk


# Payoffs in years in prison (lower is better):
# - Both cooperate (C,C): 1 year each
# - Both defect (D,D): 3 years each
# - Cooperate while other defects (C,D): cooperator 5 years, defector 0 years
PAYOFFS = {
    ("C", "C"): (1, 1),
    ("D", "D"): (3, 3),
    ("C", "D"): (5, 0),
    ("D", "C"): (0, 5),
}


class Strategy:
    @staticmethod
    def random(_history, _self_history):
        return random.choice(["C", "D"])

    @staticmethod
    def tit_for_tat(opponent_history, _self_history):
        if not opponent_history:
            return "C"
        return opponent_history[-1]

    @staticmethod
    def always_cooperate(_opponent_history, _self_history):
        return "C"

    @staticmethod
    def always_defect(_opponent_history, _self_history):
        return "D"


class PrisonersDilemmaApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Prisoner's Dilemma")
        self.geometry("720x520")

        # Game state
        self.round = 0
        self.max_rounds = 0  # 0 means unlimited until Reset
        self.history = []  # list of tuples: (p1_move, p2_move, payoff1, payoff2)
        self.scores = {"Player 1": 0, "Player 2": 0}
        self.current_moves = {}

        # Opponent config
        self.opponent_types = ["Human", "Random", "Tit-for-Tat", "Always Cooperate", "Always Defect"]

        # Sessions directory for saving/loading previous sessions
        self.sessions_dir = os.path.join(os.path.dirname(__file__), "sessions")
        self._ensure_sessions_dir()

        self._build_ui()
        # populate sessions menu
        self._refresh_sessions_menu()

    def _build_ui(self):
        # Top frame: configuration
        config_frame = ctk.CTkFrame(self)
        config_frame.pack(fill="x", padx=12, pady=8)

        ctk.CTkLabel(config_frame, text="Opponent:").grid(row=0, column=0, padx=6, pady=6)
        self.opponent_menu = ctk.CTkOptionMenu(config_frame, values=self.opponent_types)
        self.opponent_menu.set(self.opponent_types[1])
        self.opponent_menu.grid(row=0, column=1, padx=6, pady=6)

        ctk.CTkLabel(config_frame, text="Rounds (0 = unlimited):").grid(row=0, column=2, padx=6, pady=6)
        self.rounds_entry = ctk.CTkEntry(config_frame, width=80)
        self.rounds_entry.insert(0, "10")
        self.rounds_entry.grid(row=0, column=3, padx=6, pady=6)

        self.start_button = ctk.CTkButton(config_frame, text="Start / Restart", command=self.start_game)
        self.start_button.grid(row=0, column=4, padx=6, pady=6)
        # Save / Load session controls
        self.save_button = ctk.CTkButton(config_frame, text="Save Session", command=self.save_session)
        self.save_button.grid(row=0, column=5, padx=6, pady=6)

        # Sessions dropdown + load
        self.sessions_menu = ctk.CTkOptionMenu(config_frame, values=["(no sessions)"])
        self.sessions_menu.set("(no sessions)")
        self.sessions_menu.grid(row=0, column=6, padx=6, pady=6)
        self.load_button = ctk.CTkButton(config_frame, text="Load", command=self.load_selected_session)
        self.load_button.grid(row=0, column=7, padx=6, pady=6)

        # Middle frame: game controls
        game_frame = ctk.CTkFrame(self)
        game_frame.pack(fill="both", expand=True, padx=12, pady=6)

        # Left: Player controls and status
        left = ctk.CTkFrame(game_frame)
        left.pack(side="left", fill="y", padx=(0, 8), pady=6)

        self.round_label = ctk.CTkLabel(left, text="Round: 0")
        self.round_label.pack(pady=(6, 12))

        self.score_label = ctk.CTkLabel(left, text=self._score_text())
        self.score_label.pack(pady=(0, 12))

        ctk.CTkLabel(left, text="Player 1 Move:").pack(pady=(4, 2))
        p1_buttons = ctk.CTkFrame(left)
        p1_buttons.pack(pady=(0, 12))
        # keep references so we can enable/disable when rounds end
        self.p1_coop_btn = ctk.CTkButton(p1_buttons, text="Cooperate", width=120, command=lambda: self.player_move(1, "C"))
        self.p1_coop_btn.grid(row=0, column=0, padx=6)
        self.p1_def_btn = ctk.CTkButton(p1_buttons, text="Defect", width=120, command=lambda: self.player_move(1, "D"))
        self.p1_def_btn.grid(row=0, column=1, padx=6)

        ctk.CTkLabel(left, text="Player 2 Move:").pack(pady=(4, 2))
        p2_buttons = ctk.CTkFrame(left)
        p2_buttons.pack(pady=(0, 12))
        self.p2_coop_btn = ctk.CTkButton(p2_buttons, text="Cooperate", width=120, command=lambda: self.player_move(2, "C"))
        self.p2_coop_btn.grid(row=0, column=0, padx=6)
        self.p2_def_btn = ctk.CTkButton(p2_buttons, text="Defect", width=120, command=lambda: self.player_move(2, "D"))
        self.p2_def_btn.grid(row=0, column=1, padx=6)

        ctk.CTkButton(left, text="Reset Scores & History", command=self.reset_game).pack(pady=(8, 6))

        # Right: History / log
        right = ctk.CTkFrame(game_frame)
        right.pack(side="left", fill="both", expand=True)

        ctk.CTkLabel(right, text="History:").pack(pady=(6, 2), anchor="w")
        self.history_box = ctk.CTkTextbox(right, width=420, height=360)
        self.history_box.pack(padx=6, pady=(0, 12), fill="both", expand=True)
        self.history_box.configure(state="disabled")

        # Footer tips
        ctk.CTkLabel(self, text="Years in prison: (C,C)=1,1  (D,D)=3,3  (C,D)=5,0  (D,C)=0,5 (lower is better)").pack(pady=(0, 10))

        # Initialize enabled/disabled until start
        # Player 1 always enabled; Player 2 depends on opponent (human/computer)
        self._set_player1_enabled(True)
        self._set_player2_enabled(False)

    def _score_text(self):
        return f"Years — Player 1: {self.scores['Player 1']}    Player 2: {self.scores['Player 2']} (lower is better)"

    def start_game(self):
        try:
            self.max_rounds = int(self.rounds_entry.get())
        except ValueError:
            self.max_rounds = 0

        self.round = 0
        self.history.clear()
        self.scores = {"Player 1": 0, "Player 2": 0}
        self.current_moves = {}
        self._append_history("--- Game started ---")
        # Enable/disable player2 controls depending on opponent
        opponent = self.opponent_menu.get()
        if opponent == "Human":
            self._set_player2_enabled(True)
        else:
            self._set_player2_enabled(False)
        self._update_ui()

    def reset_game(self):
        self.round = 0
        self.history.clear()
        self.scores = {"Player 1": 0, "Player 2": 0}
        self.current_moves = {}
        self.history_box.configure(state="normal")
        self.history_box.delete("0.0", "end")
        self.history_box.configure(state="disabled")
        self._append_history("--- Reset ---")
        self._update_ui()

    def _ensure_sessions_dir(self):
        try:
            os.makedirs(self.sessions_dir, exist_ok=True)
        except Exception:
            # best-effort, but if it fails later save will report
            pass

    def _refresh_sessions_menu(self):
        # List json files in sessions_dir
        try:
            files = [f for f in os.listdir(self.sessions_dir) if f.endswith('.json')]
            files.sort(reverse=True)
        except Exception:
            files = []
        if not files:
            vals = ["(no sessions)"]
            self.sessions_menu.configure(values=vals)
            self.sessions_menu.set("(no sessions)")
        else:
            self.sessions_menu.configure(values=files)
            self.sessions_menu.set(files[0])

    def save_session(self):
        # Prepare session data
        data = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "opponent": self.opponent_menu.get(),
            "max_rounds": self.max_rounds,
            "round": self.round,
            "scores": self.scores,
            "history": self.history,
        }
        fname = f"session_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.json"
        path = os.path.join(self.sessions_dir, fname)
        try:
            with open(path, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
            self._append_history(f"Saved session to {fname}")
        except Exception as e:
            self._append_history(f"Failed to save session: {e}")
        self._refresh_sessions_menu()

    def load_selected_session(self):
        sel = self.sessions_menu.get()
        if not sel or sel == "(no sessions)":
            self._append_history("No session selected to load")
            return
        path = os.path.join(self.sessions_dir, sel)
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
        except Exception as e:
            self._append_history(f"Failed to load session: {e}")
            return

        # Restore state
        self.opponent_menu.set(data.get('opponent', self.opponent_types[0]) if data.get('opponent') in self.opponent_types else self.opponent_types[0])
        self.max_rounds = data.get('max_rounds', 0)
        self.round = data.get('round', 0)
        self.scores = data.get('scores', {"Player 1": 0, "Player 2": 0})
        self.history = data.get('history', [])
        # refresh UI history box
        self.history_box.configure(state='normal')
        self.history_box.delete('0.0', 'end')
        for i, h in enumerate(self.history, start=1):
            # history entries are expected as tuples [p1,p2,pay1,pay2]
            try:
                p1, p2, pay1, pay2 = h
                self.history_box.insert('end', f"Round {i}: P1={p1} P2={p2} => {pay1} yrs, {pay2} yrs\n")
            except Exception:
                self.history_box.insert('end', f"{h}\n")
        self.history_box.configure(state='disabled')
        self._append_history(f"Loaded session {sel}")
        # Update UI labels
        self._update_ui()

    def _set_player2_enabled(self, enabled: bool):
        state = "normal" if enabled else "disabled"
        self.p2_coop_btn.configure(state=state)
        self.p2_def_btn.configure(state=state)

    def _set_player1_enabled(self, enabled: bool):
        state = "normal" if enabled else "disabled"
        self.p1_coop_btn.configure(state=state)
        self.p1_def_btn.configure(state=state)

    def player_move(self, player_num, move):
        # Record move
        self.current_moves[player_num] = move
        # If opponent is computer and player 1 just moved, compute computer move immediately
        opponent = self.opponent_menu.get()
        if opponent != "Human" and player_num == 1:
            p2_move = self._compute_computer_move(opponent)
            self.current_moves[2] = p2_move

        # If both moves are present, resolve
        if 1 in self.current_moves and 2 in self.current_moves:
            self._resolve_round()

    def _compute_computer_move(self, opponent_type):
        p1_history = [h[0] for h in self.history]
        p2_history = [h[1] for h in self.history]
        if opponent_type == "Random":
            return Strategy.random(p1_history, p2_history)
        if opponent_type == "Tit-for-Tat":
            return Strategy.tit_for_tat(p1_history, p2_history)
        if opponent_type == "Always Cooperate":
            return Strategy.always_cooperate(p1_history, p2_history)
        if opponent_type == "Always Defect":
            return Strategy.always_defect(p1_history, p2_history)
        return Strategy.random(p1_history, p2_history)

    def _resolve_round(self):
        p1_move = self.current_moves.pop(1)
        p2_move = self.current_moves.pop(2)
        payoff1, payoff2 = PAYOFFS[(p1_move, p2_move)]
        self.scores["Player 1"] += payoff1
        self.scores["Player 2"] += payoff2
        self.round += 1
        self.history.append((p1_move, p2_move, payoff1, payoff2))
        self._append_history(f"Round {self.round}: P1={p1_move} P2={p2_move} => {payoff1} yrs, {payoff2} yrs")
        self._update_ui()

        # Check max rounds
        if self.max_rounds > 0 and self.round >= self.max_rounds:
            self._append_history("--- Reached max rounds ---")
            # disable buttons
            # disable both player controls
            self._set_player1_enabled(False)
            self._set_player2_enabled(False)

    def _append_history(self, text: str):
        self.history_box.configure(state="normal")
        self.history_box.insert("end", text + "\n")
        self.history_box.see("end")
        self.history_box.configure(state="disabled")

    def _update_ui(self):
        self.round_label.configure(text=f"Round: {self.round}")
        self.score_label.configure(text=self._score_text())


if __name__ == "__main__":
    app = PrisonersDilemmaApp()
    app.mainloop()
